
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';

import '../now_playing/audio_player_manager.dart' show AudioPlayerManager, DurationState;

/// MiniPlayer không phụ thuộc PlayingPage.
/// - Truyền `onOpenFullPlayer` nếu muốn mở trang full player.
/// - Nếu để null, MiniPlayer vẫn hoạt động bình thường, chỉ không điều hướng khi bấm.
class MiniPlayer extends StatelessWidget {
  final VoidCallback? onOpenFullPlayer;
  const MiniPlayer({super.key, this.onOpenFullPlayer});

  @override
  Widget build(BuildContext context) {
    final audio = AudioPlayerManager();

    // Chuẩn bị stream (idempotent nếu prepare() của bạn xử lý rồi)
    audio.prepare();

    return ValueListenableBuilder(
      valueListenable: AudioPlayerManager.currentSongNotifier,
      builder: (context, song, _) {
        if (song == null) return const SizedBox.shrink();

        final String? cover = _safeStr(() => song.image);
        final String? title = _safeStr(() => song.title);
        final String? artist = _safeStr(() => song.artist);

        final tile = SizedBox(
          height: 72,
          child: Row(
            children: [
              // Ảnh bìa
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: SizedBox.square(
                    dimension: 56,
                    child: (cover != null && cover.isNotEmpty)
                        ? Image.network(cover, fit: BoxFit.cover)
                        : Container(
                      color: Colors.black12,
                      child: const Icon(Icons.music_note),
                    ),
                  ),
                ),
              ),

              // Tiêu đề + nghệ sĩ + tiến độ
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        title ?? 'Unknown title',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const SizedBox(height: 2),
                      Text(
                        artist ?? 'Unknown artist',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                      const SizedBox(height: 6),
                      StreamBuilder<DurationState>(
                        stream: audio.durationState,
                        builder: (context, snap) {
                          final state = snap.data;
                          final pos = state?.progress ?? Duration.zero;
                          final dur = state?.total ?? Duration.zero;
                          final value = (dur.inMilliseconds == 0)
                              ? 0.0
                              : (pos.inMilliseconds / dur.inMilliseconds).clamp(0.0, 1.0);
                          return ClipRRect(
                            borderRadius: BorderRadius.circular(99),
                            child: LinearProgressIndicator(
                              value: value.isNaN ? 0 : value,
                              minHeight: 4,
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ),

              // Nút điều khiển
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    tooltip: 'Previous',
                    onPressed: audio.player.hasPrevious ? () => audio.player.seekToPrevious() : null,
                    icon: const Icon(Icons.skip_previous_rounded),
                  ),
                  StreamBuilder<PlayerState>(
                    stream: audio.player.playerStateStream,
                    builder: (context, snapshot) {
                      final playerState = snapshot.data;
                      final playing = playerState?.playing ?? false;
                      final processing = playerState?.processingState ?? ProcessingState.idle;
                      final isBuffering = processing == ProcessingState.loading ||
                          processing == ProcessingState.buffering;

                      if (isBuffering) {
                        return const SizedBox(
                          width: 48,
                          height: 48,
                          child: Padding(
                            padding: EdgeInsets.all(10.0),
                            child: CircularProgressIndicator(strokeWidth: 2),
                          ),
                        );
                      }

                      return IconButton.filledTonal(
                        tooltip: playing ? 'Pause' : 'Play',
                        onPressed: () async {
                          if (playing) {
                            await audio.player.pause();
                          } else {
                            await audio.player.play();
                          }
                        },
                        icon: Icon(playing ? Icons.pause_rounded : Icons.play_arrow_rounded),
                      );
                    },
                  ),
                  IconButton(
                    tooltip: 'Next',
                    onPressed: audio.player.hasNext ? () => audio.player.seekToNext() : null,
                    icon: const Icon(Icons.skip_next_rounded),
                  ),
                  IconButton(
                    tooltip: 'Close',
                    onPressed: () async {
                      await audio.stop(); // dừng và ẩn Mini
                    },
                    icon: const Icon(Icons.close_rounded),
                  ),
                  const SizedBox(width: 4),
                ],
              ),
            ],
          ),
        );

        return Material(
          elevation: 10,
          color: Theme.of(context).colorScheme.surface,
          child: onOpenFullPlayer == null
              ? tile
              : InkWell(onTap: onOpenFullPlayer, child: tile),
        );
      },
    );
  }
}

String? _safeStr(String? Function() getter) {
  try {
    final v = getter();
    if (v != null && v.isNotEmpty) return v;
  } catch (_) {}
  return null;
}
